﻿Try{
#Current Path
$CurrentPath = Split-Path $script:MyInvocation.MyCommand.Path
#XMl Configuration File Path
$XMLPath = "$CurrentPath\RemoveRG.xml"
##### Load XML Configuration values as variables #########
Write-Verbose "loading values from RemoveRG.xml"
$Variable=[XML] (Get-Content "$XMLPath")
$SubscriptionId = $Variable.RemoveRG.SubscriptionId
$UserName = $Variable.RemoveRG.UserName
$Password = $Variable.RemoveRG.Password
$RGName = $Variable.RemoveRG.RGName
do{                      
    if (!(Get-PackageProvider -Name NuGet -ErrorAction SilentlyContinue -ListAvailable)) 
    {
    Install-PackageProvider NuGet -Force 
    }         
    # Getting the Modules available in Azure
               
    $LoadModule=Get-Module -ListAvailable "Azure*"
                        
    if(!$LoadModule){

    # Installing Modules

    Install-Module -Name AzureRM.profile -AllowClobber -Force 
    Install-Module -Name AzureRM.resources -AllowClobber -Force
    Install-Module -Name AzureRM.Compute -AllowClobber -Force
    }
    } until($LoadModule)

    # Importing Modules 

    Import-Module AzureRM.profile
    Import-Module AzureRM.resources
    Import-Module AzureRM.Compute  
    $Securepass=ConvertTo-SecureString -String $Password -AsPlainText -Force
    $Azurecred=New-Object -TypeName System.Management.Automation.PSCredential -ArgumentList($UserName, $Securepass)
    $login=Login-AzureRmAccount -Credential $Azurecred -SubscriptionId $SubscriptionId
    $getRGInfo=Get-AzureRmResourceGroup -Name $RGName
    
    # Removing the vm created resource group

    Remove-AzureRmResourceGroup -Name $RGName -Force
    }
    catch{
    Write-Error $_.Exception.Message
    }