﻿param
(

    [Parameter(Mandatory = $True)]
    [ValidateNotNullOrEmpty()]
    [string] $SubscriptionId,

    [Parameter(Mandatory = $True)]
    [ValidateNotNullOrEmpty()]
    [string] $vmResourceGroupName,

    [Parameter(Mandatory = $True)]
    [ValidateNotNullOrEmpty()]
    [string] $UserName,

    [Parameter(Mandatory = $True)]
    [ValidateNotNullOrEmpty()]
    [string] $Password
)

    $Passwd = $Password | ConvertTo-SecureString -asPlainText -Force
    $Credential = New-Object System.Management.Automation.PSCredential($UserName,$Passwd)
    Login-AzureRmAccount -Credential $Credential
    Select-AzureRmSubscription -SubscriptionId $SubscriptionId
    Start-Sleep -Seconds 10 ; Remove-AzureRmVMCustomScriptExtension -ResourceGroupName $vmResourceGroupName -VMName "MyVM" -Name "CustomScriptExtension" -Force
    $rsg= Get-AzureRmResourceGroup -Name $vmResourceGroupName-ErrorAction SilentlyContinue
    Start-Sleep -Seconds 10 ; Remove-AzureRmResourceGroup -Name $vmResourceGroupName -Force
    