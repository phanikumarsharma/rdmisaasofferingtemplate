﻿param
(

    [Parameter(Mandatory = $True)]
    [ValidateNotNullOrEmpty()]
    [string] $SubscriptionId,

    [Parameter(Mandatory = $True)]
    [ValidateNotNullOrEmpty()]
    [string] $vmResourceGroupName,

    [Parameter(Mandatory = $True)]
    [ValidateNotNullOrEmpty()]
    [string] $UserName,

    [Parameter(Mandatory = $True)]
    [ValidateNotNullOrEmpty()]
    [string] $Password
)

try
{
    Write-Output "Login Into Azure RM.."
    
    $Passwd = $Password | ConvertTo-SecureString -asPlainText -Force
    $Credential = New-Object System.Management.Automation.PSCredential($UserName,$Passwd)
    Login-AzureRmAccount -Credential $Credential

    Write-Output "Selecting Azure Subscription.."
    Select-AzureRmSubscription -SubscriptionId $SubscriptionId
    Write-Output "Checking if the resource group $RGName exists";
    $Rsg= Get-AzureRmResourceGroup -Name $vmResourceGroupName-ErrorAction SilentlyContinue
    if ($Rsg)
    {
        Write-Output "Deleting the resource group $vmResourceGroupName...";
        Remove-AzureRmResourceGroup -Name $vmResourceGroupName-Force -ErrorAction Stop 
        Write-Output "Resource group with name $vmResourceGroupName has been deleted"
    }
}
catch [Exception]
{
    Write-Output $_.Exception.Message
}