﻿Param(
    [Parameter(Mandatory=$True)]
    [ValidateNotNullOrEmpty()]
    [string] $SubscriptionId,

    [Parameter(Mandatory=$True)]
    [ValidateNotNullOrEmpty()]
    [String] $UserName,

    [Parameter(Mandatory=$True)]
    [ValidateNotNullOrEmpty()]
    [string] $Password,

    [Parameter(Mandatory=$True)]
    [ValidateNotNullOrEmpty()]
    [string] $VMResourceGroupName
 
)


$Securepass= $Password | ConvertTo-SecureString -AsPlainText -Force
$Azurecred=New-Object -TypeName System.Management.Automation.PSCredential -ArgumentList($UserName, $Securepass)
$login=Login-AzureRmAccount -Credential $Azurecred

Select-AzureRmSubscription -SubscriptionId $SubscriptionId

$ResourceGroup= Get-AzureRmResourceGroup -Name $VMResourceGroupName
if($ResourceGroup)
{
    Remove-AzureRmResourceGroup -Name $VMResourceGroupName -Force
}
